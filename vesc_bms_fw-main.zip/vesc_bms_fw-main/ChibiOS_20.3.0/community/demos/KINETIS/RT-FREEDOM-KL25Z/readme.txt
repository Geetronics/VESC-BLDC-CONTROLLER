*****************************************************************************
** ChibiOS/RT port for ARM-Cortex-M0+ Freedom Board KL25Z.                 **
*****************************************************************************

** TARGET **

The demo runs on an Freescale Freedom KL25Z board.

** The Demo **


** Build Procedure **

The demo has been tested by using the free Codesourcery GCC-based toolchain
and YAGARTO. just modify the TRGT line in the makefile in order to use
different GCC toolchains.
